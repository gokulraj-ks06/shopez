f = open("tmp.txt", "r")
h=f.readline()
k=h.split("-")
spx=0
spy=0
epx=0
epy=0
cnt=0
for i in k:
	j=i.split(":")
	print(j)
	if cnt==0:
		spx=j[0]
		spy=j[1]
	if cnt==1:
		epx=j[0]
		epy=j[1]
	
	cnt=cnt+1
	print(cnt)
print(spx,spy,epx,epy)