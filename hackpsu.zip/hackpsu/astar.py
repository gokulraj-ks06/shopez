import cv2
import numpy as np
import heapq

rows = 10
columns = 10
a=0
spx=0
spy=0
epx=0
epy=0
def grid_map(img):
    global a,spx,spy,epx,epy
    grid = np.zeros((rows, columns))
    for i in range(rows):
        for j in range(columns):
            if (np.array_equal(img[20+(i*62), 20+(j*62)], [255,255,255])):
                grid[i][j] = 0

            else:
                grid[i][j] = 1
    grid[spx][spy]=2
    grid[epx][epy]=3
    return grid


class Cell(object):
    def __init__(self, x, y, reachable):
        self.reachable = reachable
        self.x = x
        self.y = y
        self.parent = None
        self.cost = 0
        self.heuristic = 0
        self.net_cost = 0


class Astar(object):
    def __init__(self):
        self.open = []
        heapq.heapify(self.open)
        self.closed = set()
        self.cells = []

    def init_grid(self, grid):
        for i in range(rows):
            for j in range(columns):
                if grid[i][j] == 1:
                    reachable = False
                else:
                    reachable = True
                self.cells.append(Cell(i, j, reachable))
                if(grid[i][j] == 2):
                    self.start = self.cell(i, j)
                if(grid[i][j] == 3):
                    self.end = self.cell(i, j)

    def cell(self, x, y):
        return self.cells[x*columns+y]

    def cell_heuristic(self, cell):
        return abs(cell.x-self.end.x)+abs(cell.y-self.end.y)

    def neighbour(self, cell):
        cells = []
        if cell.x < columns - 1:
            cells.append(self.cell(cell.x+1, cell.y))
        if cell.x > 0:
            cells.append(self.cell(cell.x-1, cell.y))
        if cell.y < rows-1:
            cells.append(self.cell(cell.x, cell.y+1))
        if cell.y > 0:
            cells.append(self.cell(cell.x, cell.y-1))
        return cells

    def update_cell(self, adj, cell):
        adj.cost = cell.cost + 1
        adj.heuristic = self.cell_heuristic(adj)
        adj.parent = cell
        adj.net_cost = adj.cost + adj.heuristic

    def display_path(self):
        route_path = []
        count = 0
        cell = self.end
        while cell.parent is not None:
            route_path.append([(cell.y)+1, (cell.x)+1])
            cell = cell.parent
            count += 1
        return route_path, count

    def search(self):
        heapq.heappush(self.open, (self.start.net_cost, self.start))
        while(len(self.open)):
            net_cost, cell = heapq.heappop(self.open)
            self.closed.add(cell)
            if cell is self.end:
                route_path, route_length = self.display_path()
                route_path.reverse()
                break
            neighbours = self.neighbour(cell)
            for path in neighbours:
                if path.reachable and path not in self.closed:
                    if (path.net_cost, path) in self.open:
                        if path.cost > cell.cost + 1:
                            self.update_cell(path, cell)
                    else:
                        self.update_cell(path, cell)
                        heapq.heappush(self.open, (path.net_cost, path))
        return route_path, route_length


def play(img):
    grid = grid_map(img)
    solution = Astar()
    solution.init_grid(grid)
    route_path, route_length = solution.search()

    return route_length, route_path


def main():
    global spx,spy,epx,epy
    f = open("tmp.txt", "r")
    h=f.readline()
    k=h.split("-")
    spx=0
    spy=0
    epx=0
    epy=0
    cnt=0
    for i in k:
        j=i.split(":")
        print(j)
        if cnt==0:
            spx=int(j[0])
            spy=int(j[1])
        if cnt==1:
            epx=int(j[0])
            epy=int(j[1])
        
        cnt=cnt+1
        print(cnt)
    
  
    img = cv2.imread('shop5.jpg')
    #cv2.imshow("jhkh",img)
   # cv2.waitKey(0)
    print(img[20,20])
    print(np.array_equal(img[20+(9*62), 20+(9*62)], [204,71,63]))
    route_length, route_path = play(img)
    for a in route_path[:-1]:
        k=((a[0]-1)*60)
        ke=((a[1]-1)*60)
        img = cv2.rectangle(img, (k,ke), (k+60,ke+60), (0,250,0), 7)
        img = cv2.rectangle(img, (k,ke), (k+60,ke+60), (0,0,255), -1) 
    cv2.imshow("route",img)
    cv2.waitKey(0)

    print(route_path,route_length)
    

main()