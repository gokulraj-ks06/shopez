import database
from twilio.rest import Client
def coke(string):
	account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
	auth_token = 'f6c7c81d9cbfd7ae4f204b3ce312fd66'
	client = Client(account_sid, auth_token)
		message = client.messages \
		    .create(
		         body=string,
		         from_='+12188750018',
		         to='+919629687123'
		     )

		print(message.sid)