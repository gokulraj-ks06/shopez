import database
from twilio.rest import Client
account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
auth_token = 'f6c7c81d9cbfd7ae4f204b3ce312fd66'
client = Client(account_sid, auth_token)
cnt=2
cnt2=2
cnt3=2
a="tmpcart"
b="tmppark"
c="tmptime"
while(len(a)>0):
	a=input("Add an item to your cart : ")
	database.write(a,"a!A"+str(cnt))
	cnt=cnt+1
b=input("What vehicle you will be using : ")
database.write(b,"a!B2")
c=input("What time you are coming : ")
database.write(c,"a!C2")
print("...................LOADING.......................")
f = open("tmp.txt", "w")
cnt=2
cnt2=2
cnt3=2
item="jhjh"
lis=[]
pos=[]
while(item!=None):
	item=database.read("a!A"+str(cnt))
	cnt=cnt+1
	lis.append(item)
print(lis)


f.close()
parking=0
g=database.read("a!B2")
hg=database.read("a!C2")
print(g)
if g[0]=="car" or g[0]=="bike" or g[0]=="van": 
	print("your parking space is P:",parking)
	print("at time :",hg)
	message = client.messages \
	    .create(
	         body="Your parking spot is P:"+str(parking)+" at "+str(hg),
	         from_='+12188750018',
	         to='+919629687123'
	     )

	print(message.sid)