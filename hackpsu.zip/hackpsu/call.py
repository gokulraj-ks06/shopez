import ast
ast.main(8,2,4,3)