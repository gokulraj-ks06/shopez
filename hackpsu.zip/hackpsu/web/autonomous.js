function autono()
{
    eel.autono()(change)
function change(ret)
{
    //var data=document.getElementById("dummy").innerHTML;
    alert(ret);


}
}