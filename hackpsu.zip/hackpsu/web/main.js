

function update() {
	var data = document.getElementById("data").value
	var data1 = document.getElementById("data1").value
	eel.update(data,data1)
}
function update3() {
	eel.update3()
}
function update4() {
	eel.update4()
}
function updateloc() {
	var data3 = document.getElementById("data3").value
	eel.updatel(data3)
}
function co() {
	eel.co()
}
