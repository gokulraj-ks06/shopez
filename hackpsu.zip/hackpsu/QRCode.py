import io
import database
import pyqrcode
from base64 import b64encode
import eel
from twilio.rest import Client
import os
import cv2
import ast
eel.init('web')
a=1
b=1
c=0
d=0
cnt=2
k=1
@eel.expose
def update(dummy_param,a):
	global cnt
	print(dummy_param)
	print(a)
	database.write(dummy_param,"a!A"+str(cnt))
	database.write(a,"a!B"+str(cnt))
	cnt=cnt+1
string="Your order - "
@eel.expose
def co():
	global string,k
	while k<cnt-1:
		k=k+1
		string=string+database.read("a!A"+str(k))[0]+":"+database.read("a!B"+str(k))[0]+","
	account_sid = 'AC7f19a553ade79abd9c42b7b09d625915'
	auth_token = 'f6c7c81d9cbfd7ae4f204b3ce312fd66'
	client = Client(account_sid, auth_token)
	message = client.messages \
		    .create(
		         body=string+"-"+"Order number 123",
		         from_='+12188750018',
		         to='+919629687123'
		     )

	print(message.sid)
	print(string)
@eel.expose
def updatel(i):
	print(i)
	global a,b,c,d
	if i=="dress":
		c=4
		d=5
		print("1")
	if i=="cake":
		c=7
		d=8
	if i=="coke":
		c=2
		d=9
	p1=str(a)+':'+str(b)+'-'+str(c)+':'+str(d)+'-'
	print(p1)
	f = open("tmp.txt", "w")
	f.write(p1)
	f.close()
	os.system("python astar.py")
	a=c
	b=d

eel.start('index.html')
